def addition(num1, num2):
    print("You are using addition function.")
    return (num1 + num2)