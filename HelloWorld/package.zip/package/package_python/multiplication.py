def multiplication(num1, num2):
    print("You are using multiplication function.")
    return (num1 * num2)