def division(num1, num2):
    print("You are using division function.")
    return (round(num1/num2))