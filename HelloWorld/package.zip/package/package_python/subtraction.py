def subtract(num1, num2):
    print("You are using subtraction function.")
    return (num1 - num2)