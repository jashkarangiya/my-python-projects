from package_python import addition, subtraction, multiplication, division, fibonnaciSeries, factorial


print(f"Result: {addition.addition(10, 2)}")
print(f"Result: {subtraction.subtract(10, 2)}")
print(f"Result: {multiplication.multiplication(10, 2)}")
print(f"Result: {division.division(10, 2)}")
print(f"You are using Fibonnaci Series.\nResult: {factorial.factorial(5)}")
print(f"You are using Fibonnaci Series.\nResult: {fibonnaciSeries.fibonacci(10)}")
